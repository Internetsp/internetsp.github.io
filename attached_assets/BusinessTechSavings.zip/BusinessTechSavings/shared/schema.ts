import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Quote request table
export const quoteRequests = pgTable("quote_requests", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zipCode: text("zip_code").notNull(),
  hasLLC: boolean("has_llc").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  internetPackage: text("internet_package"),
  internetQuantity: integer("internet_quantity"),
  phonePackage: text("phone_package"),
  phoneQuantity: integer("phone_quantity"),
  hasDevices: boolean("has_devices"),
  currentCarrier: text("current_carrier"),
  deviceCount: integer("device_count"),
  deviceBalance: integer("device_balance"),
  estimatedSavings: integer("estimated_savings"),
  createdAt: text("created_at").notNull(),
});

export const insertQuoteRequestSchema = createInsertSchema(quoteRequests).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertQuoteRequest = z.infer<typeof insertQuoteRequestSchema>;
export type QuoteRequest = typeof quoteRequests.$inferSelect;
