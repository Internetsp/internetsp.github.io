import { quoteRequests, users, type User, type InsertUser, type QuoteRequest, type InsertQuoteRequest } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createQuoteRequest(quoteRequest: InsertQuoteRequest): Promise<QuoteRequest>;
  getQuoteRequests(): Promise<QuoteRequest[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private quotes: Map<number, QuoteRequest>;
  userCurrentId: number;
  quoteCurrentId: number;

  constructor() {
    this.users = new Map();
    this.quotes = new Map();
    this.userCurrentId = 1;
    this.quoteCurrentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createQuoteRequest(quoteRequest: InsertQuoteRequest): Promise<QuoteRequest> {
    const id = this.quoteCurrentId++;
    const newQuoteRequest: QuoteRequest = { ...quoteRequest, id };
    this.quotes.set(id, newQuoteRequest);
    return newQuoteRequest;
  }

  async getQuoteRequests(): Promise<QuoteRequest[]> {
    return Array.from(this.quotes.values());
  }
}

export const storage = new MemStorage();
