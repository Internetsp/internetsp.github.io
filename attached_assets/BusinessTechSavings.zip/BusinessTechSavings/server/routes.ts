import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQuoteRequestSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  app.post("/api/quote-request", async (req, res) => {
    try {
      // Validate request body
      const quoteRequestData = insertQuoteRequestSchema.parse({
        ...req.body,
        createdAt: new Date().toISOString()
      });
      
      // Store quote request
      const quoteRequest = await storage.createQuoteRequest(quoteRequestData);
      
      // Return success response
      res.status(201).json({
        success: true,
        data: quoteRequest
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({
          success: false,
          message: validationError.message
        });
      } else {
        res.status(500).json({
          success: false,
          message: "Failed to submit quote request"
        });
      }
    }
  });
  
  app.get("/api/quote-requests", async (req, res) => {
    try {
      const quoteRequests = await storage.getQuoteRequests();
      res.status(200).json({
        success: true,
        data: quoteRequests
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Failed to retrieve quote requests"
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
