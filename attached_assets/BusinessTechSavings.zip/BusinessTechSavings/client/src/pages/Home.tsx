import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import StepProgress from "@/components/StepProgress";
import Step1Info from "@/components/Step1Info";
import Step2Calculator from "@/components/Step2Calculator";
import Step3Form from "@/components/Step3Form";
import { CalculatorState } from "@/types/calculator";
import { calculateSavings } from "@/utils/calculator";

const Home = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [calculatorState, setCalculatorState] = useState<CalculatorState>({
    services: {
      internet: true,
      phone: true
    },
    internet: {
      package: '300mb',
      quantity: 1
    },
    phone: {
      package: 'standard',
      quantity: 2
    },
    devicePayoff: {
      hasDevices: false,
      carrier: 'verizon',
      deviceCount: 1,
      deviceBalance: 500
    }
  });

  const handleNext = () => {
    setCurrentStep(Math.min(currentStep + 1, 3));
    window.scrollTo(0, 0);
  };

  const handleBack = () => {
    setCurrentStep(Math.max(currentStep - 1, 1));
    window.scrollTo(0, 0);
  };

  const handleCalculatorStateChange = (newState: CalculatorState) => {
    setCalculatorState(newState);
  };

  const calculationResults = calculateSavings(calculatorState);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-8 max-w-6xl flex-grow">
        <StepProgress currentStep={currentStep} />
        
        <div className="relative">
          {currentStep === 1 && (
            <Step1Info onContinue={handleNext} />
          )}
          
          {currentStep === 2 && (
            <Step2Calculator 
              onContinue={handleNext}
              onBack={handleBack}
              calculatorState={calculatorState}
              onCalculatorStateChange={handleCalculatorStateChange}
            />
          )}
          
          {currentStep === 3 && (
            <Step3Form 
              onBack={handleBack}
              calculatorState={calculatorState}
              calculationResults={calculationResults}
            />
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Home;
