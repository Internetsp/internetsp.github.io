export type InternetPackage = '10mb' | '50mb' | '300mb' | '1000mb' | '3000mb' | '5000mb';
export type PhonePackage = 'budget' | 'standard' | 'advanced';
export type Carrier = 'verizon' | 'tmobile' | 'sprint' | 'other';

export interface CalculatorState {
  services: {
    internet: boolean;
    phone: boolean;
  };
  internet: {
    package: InternetPackage;
    quantity: number;
  };
  phone: {
    package: PhonePackage;
    quantity: number;
  };
  devicePayoff: {
    hasDevices: boolean;
    carrier: Carrier;
    deviceCount: number;
    deviceBalance: number;
  };
}

export interface SavingsCalculation {
  internet: {
    marketRate: number;
    exclusiveRate: number;
  };
  phone: {
    marketRate: number;
    exclusiveRate: number;
  };
  totals: {
    currentMonthlyCost: number;
    newMonthlyCost: number;
    monthlySavings: number;
    currentAnnualCost: number;
    newAnnualCost: number;
    annualSavings: number;
    twoYearSavings: number;
    devicePayoffAmount: number;
  };
}

export interface QuoteFormData {
  firstName: string;
  lastName: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  hasLLC: boolean;
  phone: string;
  email: string;
  internetPackage?: string;
  internetQuantity?: number;
  phonePackage?: string;
  phoneQuantity?: number;
  hasDevices?: boolean;
  currentCarrier?: string;
  deviceCount?: number;
  deviceBalance?: number;
  estimatedSavings?: number;
}
