import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ServiceOption from "./ServiceOption";
import QuantitySelector from "./QuantitySelector";
import RateComparison from "./RateComparison";
import DevicePayoffSection from "./DevicePayoffSection";
import SavingsSummary from "./SavingsSummary";
import PhonePackageOptions from "./PhonePackageOptions";
import { CalculatorState, InternetPackage, PhonePackage, Carrier } from "../types/calculator";
import { calculateSavings } from "../utils/calculator";

interface Step2CalculatorProps {
  onContinue: () => void;
  onBack: () => void;
  calculatorState: CalculatorState;
  onCalculatorStateChange: (state: CalculatorState) => void;
}

const Step2Calculator = ({
  onContinue,
  onBack,
  calculatorState,
  onCalculatorStateChange
}: Step2CalculatorProps) => {
  const [calculations, setCalculations] = useState(() => calculateSavings(calculatorState));

  useEffect(() => {
    setCalculations(calculateSavings(calculatorState));
  }, [calculatorState]);

  const handleServiceChange = (service: 'internet' | 'phone', checked: boolean) => {
    onCalculatorStateChange({
      ...calculatorState,
      services: {
        ...calculatorState.services,
        [service]: checked
      }
    });
  };

  const handleInternetPackageChange = (value: string) => {
    onCalculatorStateChange({
      ...calculatorState,
      internet: {
        ...calculatorState.internet,
        package: value as InternetPackage
      }
    });
  };

  const handleInternetQuantityChange = (value: number) => {
    onCalculatorStateChange({
      ...calculatorState,
      internet: {
        ...calculatorState.internet,
        quantity: value
      }
    });
  };

  const handlePhonePackageChange = (value: PhonePackage) => {
    onCalculatorStateChange({
      ...calculatorState,
      phone: {
        ...calculatorState.phone,
        package: value
      }
    });
  };

  const handlePhoneQuantityChange = (value: number) => {
    onCalculatorStateChange({
      ...calculatorState,
      phone: {
        ...calculatorState.phone,
        quantity: value
      }
    });
  };

  const handleHasDevicesChange = (hasDevices: boolean) => {
    onCalculatorStateChange({
      ...calculatorState,
      devicePayoff: {
        ...calculatorState.devicePayoff,
        hasDevices
      }
    });
  };

  const handleCarrierChange = (carrier: Carrier) => {
    onCalculatorStateChange({
      ...calculatorState,
      devicePayoff: {
        ...calculatorState.devicePayoff,
        carrier
      }
    });
  };

  const handleDeviceCountChange = (deviceCount: number) => {
    onCalculatorStateChange({
      ...calculatorState,
      devicePayoff: {
        ...calculatorState.devicePayoff,
        deviceCount
      }
    });
  };

  const handleDeviceBalanceChange = (deviceBalance: number) => {
    onCalculatorStateChange({
      ...calculatorState,
      devicePayoff: {
        ...calculatorState.devicePayoff,
        deviceBalance
      }
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-8">
      <h2 className="text-2xl font-bold text-[#0057b8] mb-6">Calculate Your Potential Savings</h2>
      
      <div className="mb-8">
        <p className="text-lg mb-4">Select the services you're interested in:</p>
        <div className="flex flex-wrap gap-4">
          <ServiceOption
            name="service-internet"
            label="Internet"
            checked={calculatorState.services.internet}
            onChange={(checked) => handleServiceChange('internet', checked)}
          />
          <ServiceOption
            name="service-phone"
            label="Phone Lines"
            checked={calculatorState.services.phone}
            onChange={(checked) => handleServiceChange('phone', checked)}
          />
        </div>
      </div>
      
      {/* Internet Options */}
      {calculatorState.services.internet && (
        <div className="mb-8 p-6 bg-gray-50 rounded-lg">
          <h3 className="text-xl font-bold mb-4">Internet Options</h3>
          
          <div className="mb-4">
            <label className="block mb-2 font-medium">Select your desired internet package:</label>
            <Select 
              value={calculatorState.internet.package} 
              onValueChange={handleInternetPackageChange}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select Internet Package" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10mb">10mb Copper Internet</SelectItem>
                <SelectItem value="50mb">50mb Copper Internet</SelectItem>
                <SelectItem value="300mb">300mb Fiber Internet</SelectItem>
                <SelectItem value="1000mb">1000mb Fiber Internet</SelectItem>
                <SelectItem value="3000mb">3000mb Fiber Internet</SelectItem>
                <SelectItem value="5000mb">5000mb Fiber Internet</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <QuantitySelector
            value={calculatorState.internet.quantity}
            onChange={handleInternetQuantityChange}
            label="How many internet connections do you need?"
          />
          
          <RateComparison
            marketRate={calculations.internet.marketRate}
            exclusiveRate={calculations.internet.exclusiveRate}
          />
        </div>
      )}
      
      {/* Phone Line Options */}
      {calculatorState.services.phone && (
        <div className="mb-8 p-6 bg-gray-50 rounded-lg">
          <h3 className="text-xl font-bold mb-4">Phone Line Options</h3>
          
          <div className="mb-4">
            <label className="block mb-2 font-medium">Select your desired phone package:</label>
            <PhonePackageOptions
              value={calculatorState.phone.package}
              selectedValue={calculatorState.phone.package}
              onChange={handlePhonePackageChange}
            />
          </div>
          
          <QuantitySelector
            value={calculatorState.phone.quantity}
            onChange={handlePhoneQuantityChange}
            label="How many phone lines do you need?"
          />
          
          <DevicePayoffSection
            hasDevices={calculatorState.devicePayoff.hasDevices}
            carrier={calculatorState.devicePayoff.carrier}
            deviceCount={calculatorState.devicePayoff.deviceCount}
            deviceBalance={calculatorState.devicePayoff.deviceBalance}
            onHasDevicesChange={handleHasDevicesChange}
            onCarrierChange={handleCarrierChange}
            onDeviceCountChange={handleDeviceCountChange}
            onDeviceBalanceChange={handleDeviceBalanceChange}
          />
          
          <RateComparison
            marketRate={calculations.phone.marketRate}
            exclusiveRate={calculations.phone.exclusiveRate}
            label="Monthly per line"
          />
        </div>
      )}
      
      {/* Summary Section */}
      <SavingsSummary calculation={calculations} />
      
      <div className="flex justify-between">
        <Button 
          type="button"
          variant="outline" 
          onClick={onBack}
          className="space-x-2"
        >
          <span>←</span>
          <span>Back</span>
        </Button>
        <Button 
          type="button"
          onClick={onContinue}
          className="bg-[#ff7900] hover:bg-orange-600"
        >
          Get Your Free Quote <span className="ml-2">→</span>
        </Button>
      </div>
    </div>
  );
};

export default Step2Calculator;
