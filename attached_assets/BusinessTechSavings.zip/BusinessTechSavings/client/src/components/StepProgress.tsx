interface StepProgressProps {
  currentStep: number;
}

const StepProgress = ({ currentStep }: StepProgressProps) => {
  return (
    <div className="mb-8">
      <div className="flex justify-between items-center w-full md:w-3/4 mx-auto mb-4">
        <div className="step-item">
          <div className={`w-10 h-10 ${currentStep >= 1 ? 'bg-[#0057b8] text-white' : 'bg-gray-300 text-gray-600'} rounded-full flex items-center justify-center font-bold`}>
            1
          </div>
          <p className="text-sm mt-2 font-medium">Discover Savings</p>
        </div>
        
        <div className={`h-1 flex-1 mx-2 ${currentStep >= 2 ? 'bg-[#0057b8]' : 'bg-gray-300'}`} />
        
        <div className="step-item">
          <div className={`w-10 h-10 ${currentStep >= 2 ? 'bg-[#0057b8] text-white' : 'bg-gray-300 text-gray-600'} rounded-full flex items-center justify-center font-bold`}>
            2
          </div>
          <p className="text-sm mt-2 font-medium">Calculate Savings</p>
        </div>
        
        <div className={`h-1 flex-1 mx-2 ${currentStep >= 3 ? 'bg-[#0057b8]' : 'bg-gray-300'}`} />
        
        <div className="step-item">
          <div className={`w-10 h-10 ${currentStep >= 3 ? 'bg-[#0057b8] text-white' : 'bg-gray-300 text-gray-600'} rounded-full flex items-center justify-center font-bold`}>
            3
          </div>
          <p className="text-sm mt-2 font-medium">Get Your Quote</p>
        </div>
      </div>
    </div>
  );
};

export default StepProgress;
