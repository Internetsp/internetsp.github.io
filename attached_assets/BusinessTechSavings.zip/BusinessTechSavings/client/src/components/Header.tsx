import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const Header = () => {
  return (
    <header className="bg-[#0057b8] text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <div className="text-2xl font-bold">
            <span className="text-white">AT&T</span>
            <span className="text-[#ff7900]">|</span>
            <span className="text-white text-xl">Business</span>
          </div>
        </div>
        
        <div className="hidden md:flex space-x-6">
          <a href="#" className="hover:text-[#ff7900] transition">Products</a>
          <a href="#" className="hover:text-[#ff7900] transition">Services</a>
          <a href="#" className="hover:text-[#ff7900] transition">Support</a>
          <a href="#" className="hover:text-[#ff7900] transition">Contact</a>
        </div>
        
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent className="bg-[#0057b8] text-white">
              <nav className="flex flex-col gap-4 mt-8">
                <a href="#" className="text-xl hover:text-[#ff7900] transition py-2">Products</a>
                <a href="#" className="text-xl hover:text-[#ff7900] transition py-2">Services</a>
                <a href="#" className="text-xl hover:text-[#ff7900] transition py-2">Support</a>
                <a href="#" className="text-xl hover:text-[#ff7900] transition py-2">Contact</a>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
