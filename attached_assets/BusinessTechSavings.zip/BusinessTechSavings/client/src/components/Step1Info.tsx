import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

interface Step1InfoProps {
  onContinue: () => void;
}

const Step1Info = ({ onContinue }: Step1InfoProps) => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="grid md:grid-cols-2 gap-0">
        <div className="p-8 flex flex-col justify-center">
          <h1 className="text-3xl md:text-4xl font-bold text-[#0057b8] mb-4">
            Small Business Owners: Stop Overpaying on Communication
          </h1>
          <p className="text-lg mb-6">
            You could be overpaying <span className="font-bold text-[#ff7900]">$1,000's every year</span> on phone lines and fiber internet.
          </p>
          
          <div className="bg-gray-100 p-6 rounded-lg mb-6">
            <h3 className="text-xl font-bold mb-4">See if you qualify for exclusive pricing:</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-[#0057b8] mt-1 mr-2" />
                <span>Phone lines as low as <span className="font-bold">$10/line</span></span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-[#0057b8] mt-1 mr-2" />
                <span>Let carriers <span className="font-bold">pay off your devices</span></span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-[#0057b8] mt-1 mr-2" />
                <span>Free upgrades to <span className="font-bold">fastest internet</span> options</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-[#0057b8] mt-1 mr-2" />
                <span>Special pricing for <span className="font-bold">both business and family</span></span>
              </li>
            </ul>
          </div>
          
          <Button 
            className="bg-[#ff7900] hover:bg-orange-600 text-white font-bold py-3 px-6 rounded-lg transition w-full md:w-auto"
            onClick={onContinue}
          >
            Calculate My Savings <span className="ml-2">→</span>
          </Button>
        </div>
        
        <div className="bg-[#0057b8] flex items-center justify-center p-8">
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-lg shadow-lg h-48 overflow-hidden bg-gray-200">
              <svg className="w-full h-full text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path fill="currentColor" d="M4 4h16v16H4V4zm1 1v14h14V5H5zm4.79 2.093l5.793 5.793-5.793 5.793L8.5 17.293 13.086 12.7 8.5 8.207l1.293-1.114z" />
                <text x="12" y="16" fontSize="3" textAnchor="middle" fill="currentColor">Small business owner</text>
              </svg>
            </div>
            <div className="rounded-lg shadow-lg h-48 overflow-hidden bg-gray-200">
              <svg className="w-full h-full text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path fill="currentColor" d="M4 4h16v16H4V4zm1 1v14h14V5H5zm4.79 2.093l5.793 5.793-5.793 5.793L8.5 17.293 13.086 12.7 8.5 8.207l1.293-1.114z" />
                <text x="12" y="16" fontSize="3" textAnchor="middle" fill="currentColor">Business team meeting</text>
              </svg>
            </div>
            <div className="rounded-lg shadow-lg h-48 overflow-hidden bg-gray-200">
              <svg className="w-full h-full text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path fill="currentColor" d="M4 4h16v16H4V4zm1 1v14h14V5H5zm4.79 2.093l5.793 5.793-5.793 5.793L8.5 17.293 13.086 12.7 8.5 8.207l1.293-1.114z" />
                <text x="12" y="16" fontSize="3" textAnchor="middle" fill="currentColor">Fiber internet installation</text>
              </svg>
            </div>
            <div className="rounded-lg shadow-lg h-48 overflow-hidden bg-gray-200">
              <svg className="w-full h-full text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path fill="currentColor" d="M4 4h16v16H4V4zm1 1v14h14V5H5zm4.79 2.093l5.793 5.793-5.793 5.793L8.5 17.293 13.086 12.7 8.5 8.207l1.293-1.114z" />
                <text x="12" y="16" fontSize="3" textAnchor="middle" fill="currentColor">Modern smartphone</text>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Step1Info;
