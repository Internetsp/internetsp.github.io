import { formatNumber } from "../utils/calculator";
import { SavingsCalculation } from "../types/calculator";

interface SavingsSummaryProps {
  calculation: SavingsCalculation;
}

const SavingsSummary = ({ calculation }: SavingsSummaryProps) => {
  const {
    currentMonthlyCost,
    newMonthlyCost,
    monthlySavings,
    currentAnnualCost,
    newAnnualCost,
    annualSavings,
    twoYearSavings,
    devicePayoffAmount
  } = calculation.totals;

  const showDevicePayoff = devicePayoffAmount > 0;

  return (
    <div className="p-6 bg-[#0057b8] text-white rounded-lg mb-8">
      <h3 className="text-xl font-bold mb-4">Your Potential Savings Summary</h3>
      
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h4 className="font-medium mb-2">Monthly</h4>
          <div className="flex justify-between items-center mb-2">
            <span>Current Estimated Cost:</span>
            <span className="font-bold">${formatNumber(currentMonthlyCost)}</span>
          </div>
          <div className="flex justify-between items-center mb-2">
            <span>Your New Cost:</span>
            <span className="font-bold">${formatNumber(newMonthlyCost)}</span>
          </div>
          <div className="flex justify-between items-center pt-2 border-t border-white/30">
            <span>Monthly Savings:</span>
            <span className="font-bold text-xl">${formatNumber(monthlySavings)}</span>
          </div>
        </div>
        
        <div>
          <h4 className="font-medium mb-2">Annual</h4>
          <div className="flex justify-between items-center mb-2">
            <span>Current Estimated Cost:</span>
            <span className="font-bold">${formatNumber(currentAnnualCost)}</span>
          </div>
          <div className="flex justify-between items-center mb-2">
            <span>Your New Cost:</span>
            <span className="font-bold">${formatNumber(newAnnualCost)}</span>
          </div>
          <div className="flex justify-between items-center pt-2 border-t border-white/30">
            <span>Annual Savings:</span>
            <span className="font-bold text-xl">${formatNumber(annualSavings)}</span>
          </div>
        </div>
      </div>
      
      <div className="mt-6 pt-4 border-t border-white/30">
        <div className="flex justify-between items-center">
          <span className="text-lg">Total 2-Year Savings:</span>
          <span className="font-bold text-2xl">${formatNumber(twoYearSavings)}</span>
        </div>
        
        {showDevicePayoff && (
          <div className="mt-4 pt-4 border-t border-white/30">
            <div className="flex justify-between items-center">
              <span className="text-lg">Plus Device Payoff Savings:</span>
              <span className="font-bold text-2xl">${formatNumber(devicePayoffAmount)}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SavingsSummary;
