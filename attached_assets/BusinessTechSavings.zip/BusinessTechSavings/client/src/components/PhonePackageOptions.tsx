import { PhonePackage } from "../types/calculator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

interface PhonePackageOptionProps {
  value: PhonePackage;
  selectedValue: PhonePackage;
  onChange: (value: PhonePackage) => void;
}

const PhonePackageOptions = ({ value, selectedValue, onChange }: PhonePackageOptionProps) => {
  const handleChange = (value: string) => {
    onChange(value as PhonePackage);
  };

  const options = [
    {
      value: 'budget' as PhonePackage,
      label: 'Personal Budget',
      description: 'Basic features for budget-conscious users',
      price: '$10/line'
    },
    {
      value: 'standard' as PhonePackage,
      label: 'Personal Standard',
      description: 'Standard features for everyday use',
      price: '$20/line'
    },
    {
      value: 'advanced' as PhonePackage,
      label: 'Personal Advanced',
      description: 'Premium features for power users',
      price: '$30/line'
    }
  ];

  return (
    <RadioGroup 
      value={selectedValue}
      onValueChange={handleChange}
      className="grid md:grid-cols-3 gap-4"
    >
      {options.map(option => (
        <div key={option.value} className="relative">
          <RadioGroupItem
            value={option.value}
            id={`phone-package-${option.value}`}
            className="peer sr-only"
          />
          <Label
            htmlFor={`phone-package-${option.value}`}
            className="flex flex-col p-4 border rounded-lg cursor-pointer hover:border-[#0057b8] transition bg-white peer-data-[state=checked]:border-[#0057b8] peer-data-[state=checked]:border-2"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold">{option.label}</span>
              <span className="w-6 h-6 border border-gray-400 rounded-full flex items-center justify-center peer-data-[state=checked]:bg-[#0057b8] peer-data-[state=checked]:border-[#0057b8]">
                {selectedValue === option.value && (
                  <span className="w-2 h-2 bg-white rounded-full" />
                )}
              </span>
            </div>
            <p className="text-sm text-gray-600">{option.description}</p>
            <p className="mt-2 text-lg font-bold text-[#0057b8]">{option.price}</p>
          </Label>
        </div>
      ))}
    </RadioGroup>
  );
};

export default PhonePackageOptions;
