const Footer = () => {
  return (
    <footer className="bg-[#333333] text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">AT&T Business</h3>
            <p className="text-gray-300">Exclusive savings for small businesses and entrepreneurs.</p>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Products</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white">Internet</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Phone Lines</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Bundles</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Devices</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Support</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white">Contact Us</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">FAQs</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Tech Support</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Coverage Map</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Legal</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white">Terms of Service</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Accessibility</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
          <p>© {new Date().getFullYear()} AT&T Intellectual Property. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
