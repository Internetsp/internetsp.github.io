import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Carrier } from "../types/calculator";
import { formatNumber } from "../utils/calculator";

interface DevicePayoffSectionProps {
  hasDevices: boolean;
  carrier: Carrier;
  deviceCount: number;
  deviceBalance: number;
  onHasDevicesChange: (value: boolean) => void;
  onCarrierChange: (value: Carrier) => void;
  onDeviceCountChange: (value: number) => void;
  onDeviceBalanceChange: (value: number) => void;
}

const DevicePayoffSection = ({
  hasDevices,
  carrier,
  deviceCount,
  deviceBalance,
  onHasDevicesChange,
  onCarrierChange,
  onDeviceCountChange,
  onDeviceBalanceChange
}: DevicePayoffSectionProps) => {
  const handleHasDevicesChange = (value: string) => {
    onHasDevicesChange(value === "yes");
  };

  const handleCarrierChange = (value: string) => {
    onCarrierChange(value as Carrier);
  };

  const handleDeviceCountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value >= 1) {
      onDeviceCountChange(value);
    }
  };

  const handleDeviceBalanceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value >= 0) {
      onDeviceBalanceChange(value);
    }
  };

  return (
    <div className="mt-6">
      <h4 className="font-medium mb-2">Do you currently have devices you'd like paid off?</h4>
      <RadioGroup 
        value={hasDevices ? "yes" : "no"} 
        onValueChange={handleHasDevicesChange}
        className="flex space-x-4 mb-4"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="yes" id="has-devices-yes" />
          <Label htmlFor="has-devices-yes">Yes</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="no" id="has-devices-no" />
          <Label htmlFor="has-devices-no">No</Label>
        </div>
      </RadioGroup>
      
      {hasDevices && (
        <div className="p-4 border rounded-lg bg-white">
          <h5 className="font-bold mb-4">Device Payoff Information</h5>
          
          <div className="mb-4">
            <Label htmlFor="current-carrier" className="block mb-2">Current Carrier:</Label>
            <Select value={carrier} onValueChange={handleCarrierChange}>
              <SelectTrigger id="current-carrier" className="w-full">
                <SelectValue placeholder="Select carrier" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="verizon">Verizon</SelectItem>
                <SelectItem value="tmobile">T-Mobile</SelectItem>
                <SelectItem value="sprint">Sprint</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="mb-4">
            <Label htmlFor="device-count" className="block mb-2">Number of Devices:</Label>
            <Input 
              type="number" 
              id="device-count" 
              min={1} 
              value={deviceCount} 
              onChange={handleDeviceCountChange} 
              className="w-full"
            />
          </div>
          
          <div className="mb-4">
            <Label htmlFor="device-balance" className="block mb-2">Average Balance Per Device:</Label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-600">$</span>
              <Input 
                type="number" 
                id="device-balance" 
                min={0} 
                value={deviceBalance} 
                onChange={handleDeviceBalanceChange} 
                className="w-full pl-8"
              />
            </div>
          </div>
          
          <div className="p-3 bg-gray-100 rounded-lg mt-4">
            <p className="font-medium">
              Total Device Payoff: <span className="font-bold text-[#0057b8]">${formatNumber(deviceCount * deviceBalance)}</span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default DevicePayoffSection;
