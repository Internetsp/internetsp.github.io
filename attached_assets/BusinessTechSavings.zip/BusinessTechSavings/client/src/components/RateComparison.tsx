interface RateComparisonProps {
  marketRate: number;
  exclusiveRate: number;
  label?: string;
}

const RateComparison = ({ marketRate, exclusiveRate, label = "Per connection" }: RateComparisonProps) => {
  return (
    <div className="grid md:grid-cols-2 gap-6 mt-6">
      <div className="p-4 border rounded-lg bg-white">
        <h4 className="font-bold mb-2">Standard Market Rate</h4>
        <p className="text-3xl font-bold text-gray-700">${marketRate}/mo</p>
        <p className="text-sm text-gray-500">{label}</p>
      </div>
      
      <div className="p-4 border rounded-lg bg-white">
        <h4 className="font-bold mb-2">Your Exclusive Rate</h4>
        <p className="text-3xl font-bold text-[#0057b8]">${exclusiveRate}/mo</p>
        <p className="text-sm text-gray-500">{label}</p>
      </div>
    </div>
  );
};

export default RateComparison;
