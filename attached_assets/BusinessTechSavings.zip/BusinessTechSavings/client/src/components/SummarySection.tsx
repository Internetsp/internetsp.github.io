import { CalculatorState, SavingsCalculation } from "../types/calculator";
import { formatNumber, getInternetPackageDisplay, getPhonePackageDisplay } from "../utils/calculator";

interface SummarySectionProps {
  calculatorState: CalculatorState;
  calculationResults: SavingsCalculation;
}

const SummarySection = ({ calculatorState, calculationResults }: SummarySectionProps) => {
  const { services, internet, phone, devicePayoff } = calculatorState;
  const { totals } = calculationResults;

  return (
    <div className="md:col-span-2 bg-[#0057b8] p-8 text-white">
      <h2 className="text-2xl font-bold mb-6">Your Custom Quote is Almost Ready</h2>
      
      <div className="mb-6">
        <h3 className="text-xl font-medium mb-4">Your Selected Services</h3>
        
        {services.internet && (
          <div className="mb-4 p-4 bg-white/10 rounded-lg">
            <h4 className="font-bold">Internet Package</h4>
            <p className="text-lg">
              {getInternetPackageDisplay(internet.package)} × {internet.quantity}
            </p>
            <p className="mt-2">
              Exclusive Rate: ${calculationResults.internet.exclusiveRate}/mo per connection
            </p>
          </div>
        )}
        
        {services.phone && (
          <div className="mb-4 p-4 bg-white/10 rounded-lg">
            <h4 className="font-bold">Phone Lines</h4>
            <p className="text-lg">
              {getPhonePackageDisplay(phone.package)} × {phone.quantity}
            </p>
            <p className="mt-2">
              Exclusive Rate: ${calculationResults.phone.exclusiveRate}/line
            </p>
          </div>
        )}
        
        {devicePayoff.hasDevices && (
          <div className="mb-4 p-4 bg-white/10 rounded-lg">
            <h4 className="font-bold">Device Payoff</h4>
            <p>
              {devicePayoff.deviceCount} device(s) from {devicePayoff.carrier === 'other' ? 'Other Carrier' : devicePayoff.carrier}
            </p>
            <p className="mt-2">
              Total Payoff Amount: ${formatNumber(totals.devicePayoffAmount)}
            </p>
          </div>
        )}
      </div>
      
      <div className="p-4 bg-white/10 rounded-lg">
        <h3 className="font-bold mb-2">Total Estimated Savings</h3>
        <p className="text-3xl font-bold">${formatNumber(totals.twoYearSavings)}</p>
        <p>over 2 years</p>
      </div>
      
      <div className="mt-8">
        <div className="rounded-lg shadow-lg h-48 bg-gray-200 overflow-hidden">
          <svg className="w-full h-full text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
            <path fill="currentColor" d="M4 4h16v16H4V4zm1 1v14h14V5H5zm4.79 2.093l5.793 5.793-5.793 5.793L8.5 17.293 13.086 12.7 8.5 8.207l1.293-1.114z" />
            <text x="12" y="16" fontSize="3" textAnchor="middle" fill="currentColor">AT&T styled office</text>
          </svg>
        </div>
      </div>
    </div>
  );
};

export default SummarySection;
