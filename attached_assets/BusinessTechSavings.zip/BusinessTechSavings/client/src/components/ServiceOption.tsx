import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

interface ServiceOptionProps {
  name: string;
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

const ServiceOption = ({ name, label, checked, onChange }: ServiceOptionProps) => {
  return (
    <div className="flex items-center cursor-pointer p-4 border rounded-lg hover:border-[#0057b8] transition">
      <Checkbox
        id={name}
        checked={checked}
        onCheckedChange={onChange}
        className="h-5 w-5 text-[#0057b8]"
      />
      <Label htmlFor={name} className="ml-2">
        {label}
      </Label>
    </div>
  );
};

export default ServiceOption;
