import { CalculatorState, SavingsCalculation, InternetPackage, PhonePackage } from "../types/calculator";

export function getInternetMarketRate(packageType: InternetPackage): number {
  const rates: Record<InternetPackage, number> = {
    '10mb': 49,
    '50mb': 69,
    '300mb': 89,
    '1000mb': 129,
    '3000mb': 199,
    '5000mb': 299
  };
  return rates[packageType];
}

export function getInternetExclusiveRate(packageType: InternetPackage): number {
  const rates: Record<InternetPackage, number> = {
    '10mb': 29,
    '50mb': 39,
    '300mb': 59,
    '1000mb': 89,
    '3000mb': 129,
    '5000mb': 199
  };
  return rates[packageType];
}

export function getPhoneMarketRate(packageType: PhonePackage): number {
  const rates: Record<PhonePackage, number> = {
    'budget': 30,
    'standard': 45,
    'advanced': 60
  };
  return rates[packageType];
}

export function getPhoneExclusiveRate(packageType: PhonePackage): number {
  const rates: Record<PhonePackage, number> = {
    'budget': 10,
    'standard': 20,
    'advanced': 30
  };
  return rates[packageType];
}

export function getInternetPackageDisplay(packageType: InternetPackage): string {
  const names: Record<InternetPackage, string> = {
    '10mb': '10mb Copper Internet',
    '50mb': '50mb Copper Internet',
    '300mb': '300mb Fiber Internet',
    '1000mb': '1000mb Fiber Internet',
    '3000mb': '3000mb Fiber Internet',
    '5000mb': '5000mb Fiber Internet'
  };
  return names[packageType];
}

export function getPhonePackageDisplay(packageType: PhonePackage): string {
  const names: Record<PhonePackage, string> = {
    'budget': 'Personal Budget',
    'standard': 'Personal Standard',
    'advanced': 'Personal Advanced'
  };
  return names[packageType];
}

export function calculateSavings(state: CalculatorState): SavingsCalculation {
  const internetMarketRate = getInternetMarketRate(state.internet.package);
  const internetExclusiveRate = getInternetExclusiveRate(state.internet.package);
  const phoneMarketRate = getPhoneMarketRate(state.phone.package);
  const phoneExclusiveRate = getPhoneExclusiveRate(state.phone.package);

  let currentMonthlyCost = 0;
  let newMonthlyCost = 0;

  if (state.services.internet) {
    currentMonthlyCost += internetMarketRate * state.internet.quantity;
    newMonthlyCost += internetExclusiveRate * state.internet.quantity;
  }

  if (state.services.phone) {
    currentMonthlyCost += phoneMarketRate * state.phone.quantity;
    newMonthlyCost += phoneExclusiveRate * state.phone.quantity;
  }

  const monthlySavings = currentMonthlyCost - newMonthlyCost;
  const currentAnnualCost = currentMonthlyCost * 12;
  const newAnnualCost = newMonthlyCost * 12;
  const annualSavings = monthlySavings * 12;
  const twoYearSavings = annualSavings * 2;

  let devicePayoffAmount = 0;
  if (state.devicePayoff.hasDevices) {
    devicePayoffAmount = state.devicePayoff.deviceCount * state.devicePayoff.deviceBalance;
  }

  return {
    internet: {
      marketRate: internetMarketRate,
      exclusiveRate: internetExclusiveRate
    },
    phone: {
      marketRate: phoneMarketRate,
      exclusiveRate: phoneExclusiveRate
    },
    totals: {
      currentMonthlyCost,
      newMonthlyCost,
      monthlySavings,
      currentAnnualCost,
      newAnnualCost,
      annualSavings,
      twoYearSavings,
      devicePayoffAmount
    }
  };
}

export function formatNumber(number: number): string {
  return new Intl.NumberFormat().format(number);
}
